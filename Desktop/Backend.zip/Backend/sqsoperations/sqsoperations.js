// sqsoperations.js

const SQS = require("@aws-sdk/client-sqs");

async function sendMessage(sqsClient, sqsQueueUrl, message) {
    try {
        const command = new SQS.SendMessageCommand({
            QueueUrl: sqsQueueUrl,
            DelaySeconds: 10,
            MessageBody: message,
        });

        const response = await sqsClient.send(command);
        console.log("Sending a message", response);
    } catch (err) {
        console.log('Error sending message to SQS:', err);
    }
}

async function receiveAndDeleteMessage(sqsClient, sqsQueueUrl) {
    try {
        const receiveCommand = new SQS.ReceiveMessageCommand({
            MaxNumberOfMessages: 1,
            QueueUrl: sqsQueueUrl,
            WaitTimeSeconds: 20,
            VisibilityTimeout: 20,
        });

        const receiveResponse = await sqsClient.send(receiveCommand);
        console.log("Receiving a message", receiveResponse);

        const Messages = receiveResponse.Messages;
        if (!Messages) {
            console.log("No messages");
            return;
        }

        // Retrieve the first message from the body
        console.log("Message contents:", Messages[0].Body);

        // Delete the message after dealt with
        const deleteCommand = new SQS.DeleteMessageCommand({
            QueueUrl: sqsQueueUrl,
            ReceiptHandle: Messages[0].ReceiptHandle,
        });
        const deleteResponse = await sqsClient.send(deleteCommand);
        console.log("Deleting the message", deleteResponse);
    } catch (err) {
        console.log('Error receiving or deleting message from SQS:', err);
    }
}

module.exports = {
    sendMessage,
    receiveAndDeleteMessage,
};
