// externalapi.js

const axios = require('axios');

async function getDebianHomepage(apiGatewayBaseUrl) {
    try {
        const response = await axios.get(`${apiGatewayBaseUrl}/debian`);
        console.log('Debian Homepage:', response.data);
    } catch (error) {
        console.error('Error fetching Debian homepage:', error);
    }
}

async function getOpenBSDHomepage(apiGatewayBaseUrl) {
    try {
        const response = await axios.get(`${apiGatewayBaseUrl}/openbsd`);
        console.log('OpenBSD Homepage:', response.data);
    } catch (error) {
        console.error('Error fetching OpenBSD homepage:', error);
    }
}

module.exports = {
    getDebianHomepage,
    getOpenBSDHomepage,
};
