// auth.js
const Cognito = require("@aws-sdk/client-cognito-identity-provider");
const jwtVerify = require("aws-jwt-verify");

// AWS Cognito configuration
const userPoolId = "ap-southeast-2_LhwDR9xn3"; // Replace with your User Pool ID
const clientId = "7snsqlsnbkfh8pfv6cjnql8mps"; // Replace with your Cognito App Client ID

// Create JWT verifier for ID tokens
const idVerifier = jwtVerify.CognitoJwtVerifier.create({
  userPoolId: userPoolId,
  tokenUse: "id",
  clientId: clientId,
});

// Generate access token function
const generateAccessToken = async (username, password) => {
  console.log("Login attempt", username);

  try {
    const cognitoClient = new Cognito.CognitoIdentityProviderClient({
      region: "ap-southeast-2",
    });

    // Initiate authentication with Cognito
    const command = new Cognito.InitiateAuthCommand({
      AuthFlow: "USER_PASSWORD_AUTH",
      AuthParameters: {
        USERNAME: username,
        PASSWORD: password,
      },
      ClientId: clientId,
    });

    const res = await cognitoClient.send(command);
    console.log("Cognito authentication successful:", res);

    // Extract the ID token
    const IdToken = res.AuthenticationResult.IdToken;

    // Verify the ID token
    const IdTokenVerifyResult = await idVerifier.verify(IdToken);
    console.log("Cognito ID Token verified:", IdTokenVerifyResult);

    console.log("Successful login by user via Cognito", username);

    // Return the Cognito ID token to the client
    return IdToken;

  } catch (err) {
    // Handle if user is not confirmed
    if (err.name === 'UserNotConfirmedException') {
      console.log("User not confirmed:", username);
      return { error: 'UserNotConfirmedException', message: 'User not confirmed. Please confirm your email.' };
    }

    console.log("Cognito authentication failed for user", username, err);
    return false;
  }
};

// Middleware to verify a token and respond with user information
const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    console.log("JSON web token missing.");
    return res.sendStatus(401);
  }

  try {
    // Verify the Cognito ID token
    const payload = await idVerifier.verify(token);

    console.log(`authToken verified for user: ${payload['cognito:username']} at URL ${req.url}`);

    // Add user info to the request
    req.user = {
      username: payload['cognito:username'],
      // Add other attributes from the payload if needed
    };
    next();
  } catch (err) {
    console.log(
      `JWT verification failed at URL ${req.url}`,
      err.name,
      err.message
    );
    return res.sendStatus(401);
  }
};

module.exports = {
  generateAccessToken,
  authenticateToken,
};
