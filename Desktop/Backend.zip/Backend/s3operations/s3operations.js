// s3operations.js

const S3 = require("@aws-sdk/client-s3");
const S3Presigner = require("@aws-sdk/s3-request-presigner");
const fs = require('fs');

async function createBucket(bucketName, qutUsername, purpose, objectKey, videoPath) {
    const s3Client = new S3.S3Client({ region: 'ap-southeast-2' });

    const objectValue = fs.readFileSync(videoPath); // Read the video file from local disk

    // Create the bucket
    try {
        const command = new S3.CreateBucketCommand({
            Bucket: bucketName
        });
        const response = await s3Client.send(command);
        console.log("Bucket created at:", response.Location);

    } catch (err) {
        console.log('Error creating bucket:', err);
    }

    // Tag the bucket
    try {
        const taggingCommand = new S3.PutBucketTaggingCommand({
            Bucket: bucketName,
            Tagging: {
                TagSet: [
                    { Key: 'qut-username', Value: qutUsername },
                    { Key: 'purpose', Value: purpose }
                ]
            }
        });
        const taggingResponse = await s3Client.send(taggingCommand);
        console.log("Bucket tagged:", taggingResponse);
    } catch (err) {
        console.log('Error tagging bucket:', err);
    }

    // Upload the video file to the S3 bucket
    try {
        const response = await s3Client.send(
            new S3.PutObjectCommand({
                Bucket: bucketName,
                Key: objectKey, // Name of the video in S3
                Body: objectValue // Video file content as binary
            })
        );
        console.log(`Video successfully uploaded to S3. Video Name: ${objectKey}`);
        console.log('Full S3 Response:', response);

    } catch (err) {
        console.log('Error uploading video to S3:', err);
    }

    // Retrieve the object metadata from the S3 bucket
    try {
        const response = await s3Client.send(
            new S3.GetObjectCommand({
                Bucket: bucketName,
                Key: objectKey,
            })
        );
        console.log('Video metadata retrieved from S3:', response);
    } catch (err) {
        console.log('Error retrieving object from S3:', err);
    }

    // Generate a presigned URL to download the object
    try {
        const getObjectCommand = new S3.GetObjectCommand({
            Bucket: bucketName,
            Key: objectKey,
        });
        const presignedURL = await S3Presigner.getSignedUrl(s3Client, getObjectCommand, { expiresIn: 3600 });
        console.log('Pre-signed URL to get the object:', presignedURL);
    } catch (err) {
        console.log('Error generating presigned GET URL:', err);
    }

    // Generate a presigned URL to upload the object
    try {
        const putCommand = new S3.PutObjectCommand({
            Bucket: bucketName,
            Key: objectKey,
            Body: objectValue
        });
        const presignedPUTURL = await S3Presigner.getSignedUrl(s3Client, putCommand, { expiresIn: 3600 });
        console.log('Pre-signed URL to PUT the object:', presignedPUTURL);
    } catch (err) {
        console.log('Error generating presigned PUT URL:', err);
    }
}

async function listBuckets() {
    const s3Client = new S3.S3Client({ region: 'ap-southeast-2' });

    // List existing S3 buckets
    try {
        const command = new S3.ListBucketsCommand({});
        const response = await s3Client.send(command);

        console.log('List of buckets:', response);
    } catch (err) {
        console.log('Error listing buckets:', err);
    }
}

module.exports = {
    createBucket,
    listBuckets
};
