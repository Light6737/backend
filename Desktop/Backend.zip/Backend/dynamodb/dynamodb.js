require("dotenv").config();
const DynamoDB = require("@aws-sdk/client-dynamodb");
const DynamoDBLib = require("@aws-sdk/lib-dynamodb");
const fs = require('fs');
const path = require('path');

// Define constants
const qutUsername = "n11749237@qut.edu.au";
const tableName = "n11749237-audi";
const sortKey = "name";
const videoPath = path.resolve(__dirname, '../uploads/transcoded-test.mp4');

// Function to extract video metadata
function getVideoMetadata(videoPath) {
    const stats = fs.statSync(videoPath);
    const fileSizeInBytes = stats.size;
    const fileName = path.basename(videoPath);
    const uploadDate = new Date().toISOString();  // Current timestamp

    return {
        fileName,
        fileSizeInBytes,
        contentType: "video/mp4",  // Assuming the video is an MP4
        uploadDate,
    };
}

async function createDynamoTable() {
    const client = new DynamoDB.DynamoDBClient({ region: "ap-southeast-2" });
    const docClient = DynamoDBLib.DynamoDBDocumentClient.from(client);

    // Create a new table (if it doesn't already exist)
    const command = new DynamoDB.CreateTableCommand({
        TableName: tableName,
        AttributeDefinitions: [
            {
                AttributeName: "qut-username",
                AttributeType: "S",
            },
            {
                AttributeName: sortKey,
                AttributeType: "S",
            },
        ],
        KeySchema: [
            {
                AttributeName: "qut-username",
                KeyType: "HASH",
            },
            {
                AttributeName: sortKey,
                KeyType: "RANGE",
            },
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 1,
            WriteCapacityUnits: 1,
        },
    });

    try {
        const response = await client.send(command);
        console.log("Create Table command response:", response);
    } catch (err) {
        if (err.name === "ResourceInUseException") {
            console.log("Table already exists, continuing...");
        } else {
            console.log("Error creating table:", err);
            return;
        }
    }

    // Extract video metadata
    const videoMetadata = getVideoMetadata(videoPath);
    console.log("Extracted video metadata:", videoMetadata);

     // Display the purpose of using DynamoDB in the terminal
    console.log("DynamoDB is used for storing video metadata such as file name, size, content type, and upload date.");

    // Put the video metadata into DynamoDB
    const putCommand = new DynamoDBLib.PutCommand({
        TableName: tableName,
        Item: {
            "qut-username": qutUsername,
            [sortKey]: videoMetadata.fileName,
            fileSize: videoMetadata.fileSizeInBytes,
            contentType: videoMetadata.contentType,
            uploadDate: videoMetadata.uploadDate,
        },
    });

    try {
        const putResponse = await docClient.send(putCommand);
        console.log("Put command response:", putResponse);
    } catch (err) {
        console.log("Error putting object:", err);
    }

    // Get the object from DynamoDB to verify
    const getCommand = new DynamoDBLib.GetCommand({
        TableName: tableName,
        Key: {
            "qut-username": qutUsername,
            [sortKey]: videoMetadata.fileName,
        },
    });

    try {
        const getResponse = await docClient.send(getCommand);
        console.log("Item data:", getResponse.Item);
    } catch (err) {
        console.log("Error getting object:", err);
    }

    // Optionally, you can query the table if you need
    const queryCommand = new DynamoDBLib.QueryCommand({
        TableName: tableName,
        KeyConditionExpression: "#partitionKey = :username AND begins_with(#sortKey, :nameStart)",
        ExpressionAttributeNames: {
            "#partitionKey": "qut-username",
            "#sortKey": sortKey,
        },
        ExpressionAttributeValues: {
            ":username": qutUsername,
            ":nameStart": "transcoded",
        },
    });

    try {
        const queryResponse = await docClient.send(queryCommand);
        console.log("Query found these items:", queryResponse.Items);
    } catch (err) {
        console.log("Error querying items:", err);
    }
}

module.exports = { createDynamoTable };
