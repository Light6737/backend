// secretsmanager.js

const SecretsManager = require("@aws-sdk/client-secrets-manager");

async function getSecret(secretName, region = "ap-southeast-2") {
    const secretsClient = new SecretsManager.SecretsManagerClient({ region });

    try {
        const response = await secretsClient.send(
            new SecretsManager.GetSecretValueCommand({
                SecretId: secretName,
            })
        );
        const secret = response.SecretString;

        console.log('Retrieved secret:', secret);

        // If your secret is a JSON string, you can parse it:
        // const secretObject = JSON.parse(secret);
        // Use the secretObject as needed in your application

        return secret;
    } catch (error) {
        console.log('Error retrieving secret:', error);
    }
}

module.exports = {
    getSecret,
};
