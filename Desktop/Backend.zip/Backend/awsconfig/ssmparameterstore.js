// ssmparameterstore.js

const SSM = require("@aws-sdk/client-ssm");

async function getParameter(parameterName, region = "ap-southeast-2") {
    const ssmClient = new SSM.SSMClient({ region });

    try {
        const ssmResponse = await ssmClient.send(
            new SSM.GetParameterCommand({
                Name: parameterName,
            })
        );

        console.log('Retrieved parameter value:', ssmResponse.Parameter.Value);
        return ssmResponse.Parameter.Value;
    } catch (error) {
        console.log('Error retrieving parameter:', error);
    }
}

module.exports = {
    getParameter,
};
