// index.js
require("dotenv").config();
const express = require("express");
const cookieParser = require("cookie-parser");
const fileUpload = require("express-fileupload");

const { createDynamoTable } = require('./dynamodb/dynamodb');
const fs = require('fs');

const { createBucket, listBuckets } = require('./s3operations/s3operations');
const { sendMessage, receiveAndDeleteMessage } = require('./sqsoperations/sqsoperations');
const { getSecret } = require('./awsconfig/secretsmanager');
const { getParameter } = require('./awsconfig/ssmparameterstore');
const { getDebianHomepage, getOpenBSDHomepage } = require('./externalapi/externalapi');

const SQS = require("@aws-sdk/client-sqs");

const app = express();
const port = 3000;

// Middleware setup
app.use(express.json());
app.use(cookieParser());
app.use(fileUpload());

// Parse urlencoded bodies for POST form parameters
app.use(express.urlencoded({ extended: true }));

// API Gateway Base URL
const apiGatewayBaseUrl = 'https://9vzsj7bxv1.execute-api.ap-southeast-2.amazonaws.com'; // Replace with your API Gateway URL

async function main() {
    // Retrieve secret from AWS Secrets Manager
    const secret_name = "n11749237-demosecret"; // Replace with your actual secret name

    await getSecret(secret_name);

    // Retrieve parameter from AWS SSM Parameter Store
    const parameter_name = "/n11749237/demo_parameter"; // Replace with your actual parameter name

    await getParameter(parameter_name);

    // List S3 buckets
    await listBuckets();

    // Create DynamoDB Table
    await createDynamoTable();

    // SQS operations
    const message = "This is the message that will be queued.";
    const sqsQueueUrl = "https://sqs.ap-southeast-2.amazonaws.com/901444280953/n11749237-test-queu-A2"; // Replace with your SQS Queue URL
    const sqsClient = new SQS.SQSClient({ region: "ap-southeast-2" });

    // Send a message to SQS
    await sendMessage(sqsClient, sqsQueueUrl, message);

    // Receive and delete a message from SQS
    await receiveAndDeleteMessage(sqsClient, sqsQueueUrl);

    // Call API Gateway endpoints
    await getDebianHomepage(apiGatewayBaseUrl);
    await getOpenBSDHomepage(apiGatewayBaseUrl);
}

main();

// Constants for S3 operations
const bucketName = 'n11749237-test'; // Replace with your bucket name
const qutUsername = 'n11749237@qut.edu.au';
const purpose = 'prac';

// The path to your video file
const objectKey = 'transcoded-test.mp4';
const videoPath = '/home/ubuntu/775785/775785/appSkeleton/uploads/transcoded-test.mp4';

// Call the createBucket function from the s3operations module
createBucket(bucketName, qutUsername, purpose, objectKey, videoPath);

// Route handlers
const webclientRoute = require("./routes/webclient.js");
const apiRoute = require("./routes/api.js");

// Define routing
app.use("/api", apiRoute);
app.use("/", webclientRoute);

// Start the server and listen on the defined port
app.listen(port, () => {
    console.log(`Server listening on port ${port}.`);
});
