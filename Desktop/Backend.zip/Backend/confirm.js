const Cognito = require("@aws-sdk/client-cognito-identity-provider");

const clientId = "7snsqlsnbkfh8pfv6cjnql8mps"; // match signUp.js
const username = "ameyandmax";  // Match signUp.js
const confirmationCode = "209411"; // obtain from your email

async function main() {
    const client = new Cognito.CognitoIdentityProviderClient({ region: 'ap-southeast-2' });
  const command2 = new Cognito.ConfirmSignUpCommand({
    ClientId: clientId,
    Username: username,
    ConfirmationCode: confirmationCode,
  });

  res2 = await client.send(command2);
  console.log(res2);

}

main();
