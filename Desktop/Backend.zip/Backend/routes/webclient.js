// Assistance provided by ChatGPT in generating the web client logic for handling user authentication.
const express = require("express");
const router = express.Router();
const path = require("path");

// Route to serve signup page
router.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/signup.html'));
});

// Route to serve confirm page
router.get('/confirm', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/confirm.html'));
});

// Serve login page
router.get("/login", (req, res) => {
    res.sendFile(path.join(__dirname, "../public/login.html"));
});

// Serve static files (HTML, CSS, JS) without authentication
router.use(express.static(path.join(__dirname, "../public")));

module.exports = router;
