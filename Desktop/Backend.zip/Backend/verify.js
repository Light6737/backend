// verify.js
document.getElementById('verify-form').addEventListener('submit', async function(event) {
    event.preventDefault();

    const mfaCode = document.getElementById('mfa-code').value;
    const username = sessionStorage.getItem('username');
    const session = sessionStorage.getItem('mfaSession');

    const response = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, mfaCode, session }),
    });

    const data = await response.json();

    if (data.accessToken) {
        // MFA verification successful
        // Redirect or perform post-login actions
    } else {
        alert(data.message);
    }
});
